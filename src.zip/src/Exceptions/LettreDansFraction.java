package Exceptions;

public class LettreDansFraction extends Exception{

	private static final long serialVersionUID = 1L;

}
